#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @version: ??
# @license: Apache Licence 
# @Filename:    __init__.py.py
# @Author:      chaidisheng
# @contact: chaidisheng@stumail.ysu.edu.cn
# @site: https://github.com/chaidisheng
# @software: PyCharm
# @Time:        4/12/20 10:19 PM
# @torch: tensor.method or torch.method(tensor)

from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

